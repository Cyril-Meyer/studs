<?php

echo '<html>'."\n";
echo '<head>'."\n";
echo '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15">'."\n";
echo '<title>Maintenance STUdS</title>'."\n";
echo '<link rel="stylesheet" type="text/css" href="../style.css">'."\n";
echo '</head>'."\n";
echo '<body>'."\n";
echo '<table class="bandeau"><tr><td><h1><br>Maintenance StUdS !</h1></td></tr></table><br>'."\n";
print "<br><br><br><br><CENTER><H2>L'application STUdS est pour l'instant en maintenance.<br> </H2>"."\n";
print "Merci de votre compr&eacute;hension.</CENTER> "."\n";
echo '<br><br><br><br><br><br><br><br><br><br>'."\n";

// Affichage du bandeau de pied
echo '<table class="bandeaupied"><tr><td>Universit&eacute; Louis Pasteur - Strasbourg - Cr&eacute;ation : Guilhem BORGHESI - 2008</td></tr></table><br>'."\n";
echo '</body>'."\n";
echo '</html>'."\n";

?>