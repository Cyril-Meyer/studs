<?php

echo '<html>'."\n";
echo '<head>'."\n";
echo '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15">'."\n";
echo '<title>Erreur STUdS</title>'."\n";
echo '<link rel="stylesheet" type="text/css" href="../style.css">'."\n";
echo '</head>'."\n";
echo '<body>'."\n";
echo '<table class="bandeau"><tr><td><h1><br>Erreur STUdS !</h1></td></tr></table><br>'."\n";
echo '<div class=body>'."\n";
print "<br><br><br><br><CENTER><H2>Vous n'avez pas l'autorisation de voir ce r&eacute;pertoire.<br> </H2>Vous devez, pour cela, initier votre connexion depuis une machine de l'Universit&eacute;.<br> Si vous avez un compte &agrave; l'Universit&eacute;, vous pouvez &eacute;galement utiliser le <a href=\"https://www-crc.u-strasbg.fr/osiris/services/vpn\" target=_new>VPN s&eacute;curis&eacute;</a>.<br><br>"."\n";
print "Vous pouvez retourner &agrave; la page d'accueil de <a href=\"../index.php\"> STUdS</A>.</CENTER> "."\n";
echo '</div>'."\n";
echo '<br><br><br><br><br><br><br><br><br><br>'."\n";

// Affichage du bandeau de pied
echo '<table class="bandeaupied"><tr><td>Universit&eacute; Louis Pasteur - Strasbourg - Cr&eacute;ation : Guilhem BORGHESI - 2008</td></tr></table><br>'."\n";
echo '</body>'."\n";
echo '</html>'."\n";

?>
