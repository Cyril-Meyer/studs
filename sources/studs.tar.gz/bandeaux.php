<?php

function bandeau_tete(){

echo '<div class="bandeau">STUdS !</div>'."\n";

}

function sous_bandeau(){
echo '<div class="sousbandeau"><input type=submit class=boutonsousbandeau name=annuler value=Accueil> <input type=submit class=boutonsousbandeau name=exemple value=Exemple> <input type=submit class=boutonsousbandeau name=contact value=Contact><input type=submit class=boutonsousbandeau name=versions value=Versions> <input type=submit class=boutonsousbandeau name=sources value=Sources> <input type=submit class=boutonsousbandeau name=intranet value=Intranet></div>'."\n";

}

function bandeau_pied(){

echo '<div class="bandeaupied">Universit&eacute; Louis Pasteur - Strasbourg - Cr&eacute;ation : Guilhem BORGHESI - 2008</div>'."\n";

}



?>
