<?php

#Nom du serveur
$nom_serveur="studs.u-strasbg.fr";

#racine du serveur web
$racine_serveur_studs="/www-root/studs";

#adresse mail de l'administrateur de la base
$adresse_mail_administrateur="borghesi@dpt-info.u-strasbg.fr";


?>
