#!/bin/bash

tar zcf ../sources/studs.tar.gz ../*.php ../admin/*.php ../style.css ../sources/.htaccess ../sources/sources.php ../errors/* ../images/*
